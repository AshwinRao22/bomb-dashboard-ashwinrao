export {default} from './Card';
