export {default} from './CardContent';
