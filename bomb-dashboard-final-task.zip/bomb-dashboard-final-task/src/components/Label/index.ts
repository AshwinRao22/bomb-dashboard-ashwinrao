export {default} from './Label';
