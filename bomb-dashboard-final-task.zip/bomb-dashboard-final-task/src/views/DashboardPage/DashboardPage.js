import { Paper } from '@material-ui/core';
import React, { useState } from 'react';
import { Route, Switch, useRouteMatch } from 'react-router-dom';
import { BackgroundImage } from '../Home/Home';
import Summary from './Summary/Summary';
import useTotalValueLocked from '../../hooks/useTotalValueLocked';
import { useStyles } from '../Home/Home';
import useBombStats from '../../hooks/useBombStats';
import useBShareSwapperStats from '../../hooks/BShareSwapper/useBShareSwapperStats';
import useBondStats from '../../hooks/useBondStats';
import usebShareStats from '../../hooks/usebShareStats';
import useBombFinance from '../../hooks/useBombFinance';

import { useMemo } from 'react';
import useCurrentEpoch from '../../hooks/useCurrentEpoch';
import useTreasuryAllocationTimes from '../../hooks/useTreasuryAllocationTimes';
import useCashPriceInEstimatedTWAP from '../../hooks/useCashPriceInEstimatedTWAP';

const DashboardPage = () => {
  const classes = useStyles();
  const TVL = useTotalValueLocked();
  const bombStats = useBombStats();
  const bShareStats = usebShareStats();
  const tBondStats = useBondStats();
  const cashStat = useCashPriceInEstimatedTWAP();

  const bombPriceInDollars = useMemo(
    () => (bombStats ? Number(bombStats.priceInDollars).toFixed(2) : null),
    [bombStats],
  );
  const bombPriceInBNB = useMemo(() => (bombStats ? Number(bombStats.tokenInFtm).toFixed(4) : null), [bombStats]);
  const bombCirculatingSupply = useMemo(() => (bombStats ? String(bombStats.circulatingSupply) : null), [bombStats]);
  const bombTotalSupply = useMemo(() => (bombStats ? String(bombStats.totalSupply) : null), [bombStats]);

  const bSharePriceInDollars = useMemo(
    () => (bShareStats ? Number(bShareStats.priceInDollars).toFixed(2) : null),
    [bShareStats],
  );
  const bSharePriceInBNB = useMemo(
    () => (bShareStats ? Number(bShareStats.tokenInFtm).toFixed(4) : null),
    [bShareStats],
  );
  const bShareCirculatingSupply = useMemo(
    () => (bShareStats ? String(bShareStats.circulatingSupply) : null),
    [bShareStats],
  );
  const bShareTotalSupply = useMemo(() => (bShareStats ? String(bShareStats.totalSupply) : null), [bShareStats]);

  const tBondPriceInDollars = useMemo(
    () => (tBondStats ? Number(tBondStats.priceInDollars).toFixed(2) : null),
    [tBondStats],
  );
  const tBondPriceInBNB = useMemo(() => (tBondStats ? Number(tBondStats.tokenInFtm).toFixed(4) : null), [tBondStats]);
  const tBondCirculatingSupply = useMemo(
    () => (tBondStats ? String(tBondStats.circulatingSupply) : null),
    [tBondStats],
  );
  const tBondTotalSupply = useMemo(() => (tBondStats ? String(tBondStats.totalSupply) : null), [tBondStats]);

  //   const bombLpZap = useZap({ depositTokenName: 'BOMB-BTCB-LP' });
  //   const bshareLpZap = useZap({ depositTokenName: 'BSHARE-BNB-LP' });

  // for Epoch summary through summary
  const currentEpoch = useCurrentEpoch();
  const { to } = useTreasuryAllocationTimes();
  const scalingFactor = useMemo(() => (cashStat ? Number(cashStat.priceInDollars).toFixed(4) : null), [cashStat]);

  // random initial value > current value
  const [lastTWAP, setLastTWAP] = useState(scalingFactor + 0.2); 
  const now = new Date();

  if (now === to) {
    setLastTWAP(scalingFactor);
  }

  //   console.log(to);
//   console.log(scalingFactor);
  const epochDataHelper = {
    TVL: TVL,
    currentEpoch: currentEpoch,
    nextEpochIn: to,
    currentTWAP: scalingFactor,
    lastTWAP: lastTWAP,
  };

  //   console.log(epochDataHelper.currentEpoch);
  // for table through summary

  const dashboardHelper = [
    {
      name: '$Bomb',
      price: bombPriceInDollars,
      tSupply: bombTotalSupply,
      cSupply: bombCirculatingSupply,
    },
    {
      name: '$BShare',
      price: bSharePriceInDollars,
      tSupply: bShareTotalSupply,
      cSupply: bShareCirculatingSupply,
    },
    {
      name: '$BBond',
      price: tBondPriceInDollars,
      tSupply: tBondTotalSupply,
      cSupply: tBondCirculatingSupply,
    },
  ];
  //   console.log(epochDataHelper.TVL);
  //   console.log(epochDataHelper);
  return (
    <div>
      <BackgroundImage />
      <Summary epochDataHelper={epochDataHelper} dashboardHelper={dashboardHelper} />
    </div>
  );
};

export default DashboardPage;
