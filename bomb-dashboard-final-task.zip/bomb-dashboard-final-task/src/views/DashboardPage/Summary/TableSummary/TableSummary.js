import React from 'react';
import './TableSummary.css';

const roundHelper = (num, k) => {
  // console.log((num / 100).toFixed(2));
  if(!num){
    return '0';
  }
  if(num >= 1000000) {
    return String((num / 1000000 ).toFixed(k)) + 'M';
  }
  if(num >= 1000) {
    return String((parseFloat(num)/1000.0).toFixed(k)) + 'k';
  }
  return String(parseFloat(num).toFixed(k)) ;
}

const TableSummary = ({dashboardHelper}) => {

  // console.log(dashboardHelper);
  return (
    <table>
      <tr>
        <th></th>
        <th></th>
        <th>Current Supply</th>
        <th>Total Supply</th>
        <th>price</th>
        <th></th>
      </tr>
      {
        dashboardHelper.map(item => (
          <tr>
            <td>icon</td>
            <td>{item.name}</td>
            <td>{ roundHelper(item.cSupply, 2 ) }</td>
            <td>{ roundHelper( item.tSupply, 2 ) }</td>
            <td>
              <p>
                ${ item.price }
                <br />
                1.05 BTCB
              </p>
            </td>
            <td>fox</td>
          </tr>
        ))
      }
    </table>
  );
};

export default TableSummary;