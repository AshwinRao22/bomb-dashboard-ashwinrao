import './summary.css';

import React from 'react';
import { Box, Button, Card, CardContent, Grid, Paper } from '@material-ui/core';
import TableSummary from './TableSummary/TableSummary';
import EpochSummary from './EpochSummary/EpochSummary';
import './summary.css';

const Summary = (props) => {
    // console.log(props.dashboardHelper);
    return (
        <Grid item xs={8} style={{margin: 'auto'}}>
          <Paper >
            <Box p={2} m={2} style={{textAlign:'center' }}>
              <div style={{ width:'100%', fontSize:'1.5em' }}><p >Bomb Finance Summary</p></div>

              <Box m={0} p={0} style={{display: 'flex', alignItems:'center', justifyContent:'space-between'}}>
                <Box m={3} xs={6} >
                  <TableSummary dashboardHelper={props.dashboardHelper} />
                </Box>
                <Box m={3} xs={3} >
                  <EpochSummary epochDataHelper={props.epochDataHelper} />
                </Box>
              </Box>
            </Box>

          </Paper>  
        </Grid>
    );
}

export default Summary;