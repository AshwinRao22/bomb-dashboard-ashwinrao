import React from 'react';
import './EpochSummary.css';
import ProgressCountdown from '../../../Boardroom/components/ProgressCountdown';
import moment from 'moment';

const EpochSummary = ({epochDataHelper}) => {
  return (
    <div class="contain">
      <div>
        <p class="comment">
          <strong>Current Epoch</strong>
        </p>
        <p class="info">{ Number(epochDataHelper.currentEpoch) }</p>
      </div>
      <div>
        <p class="info"><ProgressCountdown base={moment().toDate()} hideBar={true} deadline={epochDataHelper.nextEpochIn} description="Next Epoch" /></p>
        <p class="comment">
          <strong>Next Epoch in</strong>
        </p>
      </div>
      <div>
        <p>
          Live TWAP: <span class="green">{ parseFloat(epochDataHelper.currentTWAP).toFixed(2) }</span>
        </p>
        <p>
          TVL: <span class="green">{'$' + Math.round( epochDataHelper.TVL )}</span>
        </p>
        <p>
          Last Epoch TWAP: <span class="green">{ parseFloat(epochDataHelper.lastTWAP).toFixed(2) }</span>
        </p>
      </div>
    </div>
  );
};

export default EpochSummary;
