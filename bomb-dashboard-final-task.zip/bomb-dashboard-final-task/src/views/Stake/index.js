export { default } from './Stake';
