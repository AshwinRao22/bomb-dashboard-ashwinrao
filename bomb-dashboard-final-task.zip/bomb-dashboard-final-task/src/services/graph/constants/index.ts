const THE_GRAPH = 'https://api.thegraph.com/subgraphs/name/acryptosx/balancer-v2';

export const GRAPH_HOST = THE_GRAPH;
